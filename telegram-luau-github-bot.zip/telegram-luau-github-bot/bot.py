import json
import os
import re
import time
from pathlib import Path
from urllib.parse import quote

import requests

TELEGRAM_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
ALLOWED_USER_ID = os.environ.get("TELEGRAM_ALLOWED_USER_ID", "").strip()
OPENAI_API_KEY = os.environ["OPENAI_API_KEY"]
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-5.5").strip() or "gpt-5.5"
GITHUB_TOKEN = os.environ["GITHUB_TOKEN"]
REPOSITORY = os.environ["GITHUB_REPOSITORY"]
BRANCH = os.environ.get("GITHUB_REF_NAME", "main")
API_BASE = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}"
ROOT = Path(".").resolve()
GENERATED = ROOT / "generated"
OFFSET_FILE = ROOT / "offset.txt"
MAX_FILE_BYTES = 45000
MAX_MESSAGE_CHARS = 3900

session = requests.Session()
session.headers.update({"User-Agent": "telegram-luau-github-bot"})


def telegram(method, payload=None, files=None, timeout=35):
    response = session.post(
        f"{API_BASE}/{method}",
        data=payload or {},
        files=files,
        timeout=timeout,
    )
    response.raise_for_status()
    data = response.json()
    if not data.get("ok"):
        raise RuntimeError(f"Telegram API error: {data}")
    return data["result"]


def send_text(chat_id, text):
    text = str(text)
    if not text:
        text = "ไม่มีข้อความตอบกลับ"
    for start in range(0, len(text), MAX_MESSAGE_CHARS):
        telegram("sendMessage", {
            "chat_id": chat_id,
            "text": text[start:start + MAX_MESSAGE_CHARS],
            "disable_web_page_preview": True,
        })


def send_file(chat_id, path):
    with path.open("rb") as handle:
        telegram(
            "sendDocument",
            {"chat_id": chat_id, "caption": path.name},
            files={"document": (path.name, handle)},
            timeout=60,
        )


def safe_relative_path(value):
    value = value.strip().replace("\\", "/")
    if not value or value.startswith("/") or ".." in Path(value).parts:
        raise ValueError("ชื่อไฟล์ไม่ถูกต้อง")
    if not re.fullmatch(r"[A-Za-z0-9ก-๙_. /-]+", value):
        raise ValueError("ชื่อไฟล์มีอักขระที่ไม่รองรับ")
    path = (ROOT / value).resolve()
    if ROOT not in path.parents:
        raise ValueError("ไม่อนุญาตให้อ่านไฟล์นอก Repository")
    if path.name in {".env", "offset.txt"} or ".git" in path.parts:
        raise ValueError("ไม่อนุญาตให้เข้าถึงไฟล์นี้")
    return path


def list_project_files():
    results = []
    for folder in (ROOT, GENERATED):
        if not folder.exists():
            continue
        for path in folder.rglob("*"):
            if path.is_file() and ".git" not in path.parts:
                rel = path.relative_to(ROOT).as_posix()
                if rel not in {"offset.txt"} and not rel.startswith(".github/"):
                    results.append(rel)
    return sorted(set(results))[:100]


def openai_generate(prompt, existing_name=None, existing_code=None):
    task = (
        "You are a senior Roblox Luau developer. Write correct, practical Roblox "
        "Luau code. Respond with exactly one JSON object and no Markdown fences: "
        '{"filename":"generated/example.luau","code":"full source code here","notes":"brief Thai explanation"}. '
        "The filename must be a relative path under generated/, end in .luau or .lua, "
        "contain only letters, digits, underscore, hyphen, dot, and slash, and must "
        "not contain '..'. Return the complete file, not a patch. Do not include "
        "secrets. If a request requires a server/client split, choose one clear "
        "entry file and explain where it belongs in notes. Never claim the code "
        "was tested in Roblox Studio unless it actually was."
    )
    if existing_name is not None:
        task += (
            f"\nThe user asked to edit the existing file {existing_name}. "
            "Keep its purpose and improve it according to the request. "
            "Return the edited complete file using the same filename."
        )
    user_content = f"คำสั่งผู้ใช้:\n{prompt}"
    if existing_code is not None:
        user_content += f"\n\nโค้ดเดิมของ {existing_name}:\n```lua\n{existing_code}\n```"

    response = session.post(
        "https://api.openai.com/v1/responses",
        headers={
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json",
        },
        json={
            "model": OPENAI_MODEL,
            "instructions": task,
            "input": user_content,
        },
        timeout=180,
    )
    if response.status_code >= 400:
        raise RuntimeError(f"OpenAI API ตอบกลับ HTTP {response.status_code}: {response.text[:1000]}")
    data = response.json()
    output = data.get("output_text")
    if not output:
        parts = []
        for item in data.get("output", []):
            for content in item.get("content", []):
                if content.get("type") == "output_text":
                    parts.append(content.get("text", ""))
        output = "\n".join(parts)
    if not output:
        raise RuntimeError("AI ไม่ได้ส่งข้อความกลับมา")
    try:
        result = json.loads(output)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", output, re.DOTALL)
        if not match:
            raise RuntimeError("อ่านรูปแบบผลลัพธ์จาก AI ไม่ได้ กรุณาลองสั่งใหม่")
        result = json.loads(match.group(0))
    filename = result.get("filename", "")
    code = result.get("code", "")
    notes = result.get("notes", "")
    if not isinstance(filename, str) or not isinstance(code, str) or not code.strip():
        raise RuntimeError("AI ส่งข้อมูลไฟล์ไม่ครบ")
    filename = filename.replace("\\", "/")
    if not filename.startswith("generated/") or not re.fullmatch(
        r"generated/[A-Za-z0-9_./-]+\.(?:luau|lua)", filename
    ) or ".." in Path(filename).parts:
        raise RuntimeError("AI ส่งชื่อไฟล์ที่ไม่ปลอดภัย")
    if len(code.encode("utf-8")) > MAX_FILE_BYTES:
        raise RuntimeError("โค้ดมีขนาดใหญ่เกินกำหนด 45 KB")
    return filename, code, notes


def handle_command(chat_id, user_id, text):
    if not ALLOWED_USER_ID or str(user_id) != ALLOWED_USER_ID:
        send_text(chat_id, "บัญชีนี้ไม่ได้รับอนุญาตให้ใช้บอท หรือยังไม่ได้ตั้ง TELEGRAM_ALLOWED_USER_ID")
        return

    command, _, argument = text.partition(" ")
    command = command.split("@")[0].lower()
    argument = argument.strip()

    if command in {"/start", "/help"}:
        send_text(
            chat_id,
            "Roblox Luau AI Bot\n\n"
            "/new คำอธิบาย — สร้างโค้ดใหม่\n"
            "/edit generated/file.luau คำสั่งแก้ไข — แก้ไฟล์เดิม\n"
            "/read generated/file.luau — อ่านไฟล์\n"
            "/files — รายการไฟล์ในโปรเจกต์\n"
            "/help — วิธีใช้\n\n"
            "โค้ดที่สร้างจะอยู่ใน generated/ และถูกบันทึกขึ้น GitHub หลัง Workflow ทำงานเสร็จ",
        )
        return

    if command == "/files":
        items = list_project_files()
        send_text(chat_id, "ไฟล์ใน Repository:\n" + ("\n".join(items) if items else "ยังไม่มีไฟล์"))
        return

    if command == "/read":
        if not argument:
            send_text(chat_id, "วิธีใช้: /read generated/example.luau")
            return
        path = safe_relative_path(argument)
        if not path.is_file():
            send_text(chat_id, "ไม่พบไฟล์นี้")
            return
        if path.stat().st_size > MAX_FILE_BYTES:
            send_text(chat_id, "ไฟล์ใหญ่เกินไป ส่งเป็นไฟล์แทน")
            send_file(chat_id, path)
            return
        content = path.read_text(encoding="utf-8")
        send_text(chat_id, f"{path.relative_to(ROOT).as_posix()}\n\n{content}")
        return

    if command == "/new":
        if not argument:
            send_text(chat_id, "วิธีใช้: /new สร้างระบบ Sprint พร้อม Stamina")
            return
        send_text(chat_id, "กำลังให้ AI เขียนโค้ด กรุณารอสักครู่")
        filename, code, notes = openai_generate(argument)
    elif command == "/edit":
        parts = argument.split(maxsplit=1)
        if len(parts) != 2:
            send_text(chat_id, "วิธีใช้: /edit generated/example.luau เพิ่มระบบ Double Jump")
            return
        filename_arg, prompt = parts
        old_path = safe_relative_path(filename_arg)
        if not old_path.is_file():
            send_text(chat_id, "ไม่พบไฟล์เดิม ใช้ /files เพื่อตรวจชื่อไฟล์")
            return
        if old_path.suffix.lower() not in {".lua", ".luau"}:
            send_text(chat_id, "แก้ไขได้เฉพาะไฟล์ .lua หรือ .luau")
            return
        old_code = old_path.read_text(encoding="utf-8")
        send_text(chat_id, "กำลังอ่านไฟล์เดิมและแก้โค้ด กรุณารอสักครู่")
        filename, code, notes = openai_generate(prompt, filename_arg, old_code)
    else:
        send_text(chat_id, "ไม่รู้จักคำสั่ง ใช้ /help เพื่อดูคำสั่ง")
        return

    output_path = safe_relative_path(filename)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(code.rstrip() + "\n", encoding="utf-8")
    send_text(chat_id, f"สร้างไฟล์แล้ว: {filename}\n{notes}".strip())
    send_file(chat_id, output_path)


def main():
    GENERATED.mkdir(parents=True, exist_ok=True)
    try:
        offset = int(OFFSET_FILE.read_text(encoding="utf-8").strip() or "0")
    except (FileNotFoundError, ValueError):
        offset = 0

    try:
        updates = telegram(
            "getUpdates",
            {"offset": offset, "timeout": 20, "allowed_updates": json.dumps(["message"])},
            timeout=30,
        )
    except Exception as exc:
        print(f"Telegram polling failed: {exc}")
        raise

    highest_update_id = offset - 1
    for update in updates:
        update_id = update.get("update_id")
        if isinstance(update_id, int):
            highest_update_id = max(highest_update_id, update_id)
        message = update.get("message") or {}
        text = message.get("text", "")
        chat = message.get("chat") or {}
        sender = message.get("from") or {}
        if not text or not chat.get("id"):
            continue
        try:
            handle_command(chat["id"], sender.get("id"), text)
        except Exception as exc:
            print(f"Command failed: {exc}")
            send_text(chat["id"], f"ทำงานไม่สำเร็จ: {str(exc)[:1200]}")

    if highest_update_id >= offset:
        OFFSET_FILE.write_text(f"{highest_update_id + 1}\n", encoding="utf-8")
    print(f"Processed {len(updates)} Telegram update(s); next offset={highest_update_id + 1}")


if __name__ == "__main__":
    main()
