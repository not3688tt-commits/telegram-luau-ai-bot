# Telegram Luau AI Bot + GitHub Actions

Telegram bot สำหรับสั่ง AI สร้าง/แก้ไข Roblox Luau โดยใช้ GitHub Actions เป็น worker

## Commands

- `/new คำอธิบาย` สร้างไฟล์ Luau ใหม่
- `/edit generated/example.luau คำสั่งแก้ไข` แก้ไฟล์เดิม
- `/read generated/example.luau` อ่านไฟล์
- `/files` ดูไฟล์
- `/help` ดูคำสั่ง

## Setup

1. สร้าง Telegram bot ผ่าน `@BotFather` แล้วคัดลอก bot token
2. สร้าง GitHub repository ใหม่และอัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้
3. ไปที่ Settings → Secrets and variables → Actions
4. เพิ่ม Repository secrets:
   - `TELEGRAM_BOT_TOKEN`: token จาก BotFather
   - `OPENAI_API_KEY`: API key ที่ใช้เรียก OpenAI API
5. เพิ่ม Repository variables:
   - `TELEGRAM_ALLOWED_USER_ID`: Telegram numeric user ID ที่อนุญาตให้ใช้บอท
   - `OPENAI_MODEL`: ชื่อโมเดลที่ API account ของคุณรองรับ เช่น `gpt-5.5`
6. ไปที่ Settings → Actions → General → Workflow permissions แล้วเลือก Read and write permissions
7. ไปที่ Actions และเปิดใช้งาน workflows หาก GitHub ขอให้อนุญาต
8. เปิด workflow `Telegram Luau AI Bot` แล้วกด Run workflow หนึ่งครั้ง
9. ส่ง `/start` ให้บอทใน Telegram

## Important limitation

GitHub Actions schedule ไม่ได้ตอบกลับแบบทันที โดย cron นี้ตรวจข้อความทุก 5 นาที และเวลาเริ่มงานอาจล่าช้าได้ โค้ดนี้ประมวลผล Telegram updates ที่รออยู่ในคิวเมื่อ workflow เริ่มทำงาน

อย่าใส่ token หรือ API key ลงใน source code และอย่าเปิด repository เป็น public หากมีข้อมูลลับ

โค้ดที่ AI สร้างยังต้องตรวจสอบและทดสอบใน Roblox Studio ก่อนใช้งานจริง
